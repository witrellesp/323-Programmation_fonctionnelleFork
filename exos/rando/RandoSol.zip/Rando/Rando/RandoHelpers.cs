﻿using Gpx;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Rando
{
    public static class RandoHelpers
    {
        public static double TrackLengthByAggregate(List<GpxTrackPoint> trackPoints)
        {
            // Calcul de la longueur
            return trackPoints.
                Select(trackPts => new { Lon = trackPts.Longitude, Lat = trackPts.Latitude, Alt = trackPts.Elevation ?? 0, Dst = 0.0 }).
                Aggregate(
                    new { Lon = 0.0, Lat = 0.0, Alt = 0.0, Dst = 0.0 },
                    (a, b) => new { Lon = b.Lon, Lat = b.Lat, Alt = b.Alt, Dst = a.Dst + (new Vector3((float)b.Lon, (float)b.Lat, (float)b.Alt) - new Vector3((float)a.Lon, (float)a.Lat, (float)a.Alt)).Length() }
                ).
                Dst / 100;
        }

        private static Vector3 Tp2Vector(GpxTrackPoint trackPoint)
        {
            return new Vector3((float)trackPoint.Longitude, (float)trackPoint.Latitude, (float)trackPoint.Elevation);
        }

        public static double TrackLengthRecursive(List<GpxTrackPoint> track)
        {
            if (track.Count == 2)
            {
                return Vector3.Subtract(Tp2Vector(track[0]), Tp2Vector(track[1])).Length()/100;
            }
            else
            {
                int middle = track.Count / 2;
                List<GpxTrackPoint> first = track.Take(middle + 1).ToList();
                List<GpxTrackPoint> second = track.Skip(middle).ToList();

                return TrackLengthRecursive(first) + TrackLengthRecursive(second);
            }
        }


    }
}
