﻿Random alea = new Random();

SquareState[,] silkyWay = new SquareState[8, 8];

silkyWay[0, 0] = SquareState.SILKY; // A1
silkyWay[7, 7] = SquareState.SILKY; // H8

void DrawBoard(SquareState[,] board)
{
    Console.WriteLine("  1 2 3 4 5 6 7 8");
    Console.WriteLine(" ┌────────────────┐");
    for (char row = 'A'; row <= 'H'; row++)
    {
        Console.Write(row + "│");
        for (int col = 1; col <= 8; col++)
        {
            switch (board[row - 'A', col - 1])
            {
                case SquareState.SILKY:
                    Console.BackgroundColor = ConsoleColor.Yellow;
                    break;
                case SquareState.VISITED:
                    Console.BackgroundColor = ConsoleColor.Green;
                    break;
                default:
                    Console.BackgroundColor = ConsoleColor.Black;
                    break;
            }
            Console.Write("  ");
            Console.BackgroundColor = ConsoleColor.Black;
        }
        Console.WriteLine("│");
    }
    Console.WriteLine(" └────────────────┘");
}

// TODO Put silk on 30 more squares
int silkSquares = 30;
while (silkSquares > 0)
{
    int row = alea.Next(0, 8);
    int col = alea.Next(0, 8);
    if (silkyWay[row, col] == SquareState.RAW)
    {
        silkyWay[row, col] = SquareState.SILKY;
        silkSquares--;
    }
}

DrawBoard(silkyWay);

// TODO Write the recursive function
// Recursive function that tells if we can reach H8 from the given position
// The algorithm is in fact simple to spell out (even in french ;)):
//
//      Je peux sortir depuis cette case si:
//          1. Je suis sur H8
//
//              ou
//
//          2. Je peux sortir depuis une des cases où je peux aller (et où je ne suis pas encore allé)

bool CanDoItFrom(int x, int y)
{
    if (x == 7 && y == 7) return true;                          // H8 is the goal

    if (x < 0 || y < 0 || x > 7 || y > 7) return false;         // outside the board
    if (silkyWay[x, y] != SquareState.SILKY) return false;      // I only walk on silk
    if (silkyWay[x, y] == SquareState.VISITED) return false;    // don't go in circles
    silkyWay[x, y] = SquareState.VISITED;                                     // mark our passing

    if (
        CanDoItFrom(x + 1, y) ||
        CanDoItFrom(x, y + 1) ||
        CanDoItFrom(x - 1, y) ||
        CanDoItFrom(x, y - 1) ||
        CanDoItFrom(x + 1, y + 1) ||
        CanDoItFrom(x - 1, y + 1) ||
        CanDoItFrom(x + 1, y - 1) ||
        CanDoItFrom(x - 1, y - 1)
        )
    {
        return true;
    }
    else { return false; }
}

// TODO Call the function and show the results
if (CanDoItFrom(0, 0))
{
    Console.WriteLine("Yes");
    silkyWay[7, 7] = SquareState.VISITED;
    DrawBoard(silkyWay);
}
else
{
    Console.WriteLine("No");
}

Console.ReadLine();

enum SquareState
{
    RAW,
    SILKY,
    VISITED
};
